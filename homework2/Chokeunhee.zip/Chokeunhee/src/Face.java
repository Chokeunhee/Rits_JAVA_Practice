/*
 * Face which is an upper class of types of PacMan
 * Created by Cho keun hee
 * Made on December 2nd 2019
 */


import java.awt.Color;
import java.awt.Graphics;

public class Face {
	private int size;
	private int xCenter;
	private int yCenter;
	private int angle;

	public Face() {
	}
	
	
	public Face(int size_, int x_, int y_, int angle_) {
		setSize(size_);
		setXCenter(x_);
		setYCenter(y_);
		setAngle(angle_);
	}
	
	int getSize() {
		return(size);
	}
	
	void setSize(int num) {
		size = num;
		if(xCenter != 0 && yCenter != 0) {
			setXCenter(getXCenter());
			setYCenter(getYCenter());
		}
	}
	
	int getXCenter() {
		return(xCenter);
	}
	
	void setXCenter(int num) {
		if(size != 0) {
			if(num < size/2) {
				size = num * 2;
			}
			if(num + size/2 > 500) {
				size = (500 - num) * 2;
			}
		}
		xCenter = num;
	}
	
	
	int getYCenter() {
		return(yCenter);
	}
	
	void setYCenter(int num) {
		if(size != 0) {
			if(num - size/2 < 25) {
				size = (num - 25) * 2;
			}
			if(num + size/2 > 450) {
				size = (450 - num) * 2;
			}
		}
		yCenter = num;		
	}
	
	int getAngle() {
		return(angle);
		
	}
	
	void setAngle(int num) {
		angle = num;
		if(num>90) {
			angle = 90;
		}else {
			angle = num;
		}
	}
	
	
	void make(Graphics g) {
		g.setColor(Color.yellow);
		g.fillArc(xCenter - size / 2, yCenter - size /2 , size , size, angle / 2, 360 - angle);	
	}
	
	void Deadmake(Graphics g) {
		g.setColor(Color.gray);
		g.fillArc(xCenter - size / 2, yCenter - size /2 , size , size, angle / 2, 360 - angle);
	}
}
	

