/*
 * data of PacMan
 * Created by Cho keun hee
 * Made on December 2nd 2019
 */

import java.awt.Graphics;

public class PacMan extends Face{
	
	public PacMan(int size_ , int x_ , int y_ , int angle_ ) {
		super(size_ , x_ , y_ , angle_ );
	}
	
	void make(Graphics g) {
		super.make(g);
	}
}