/*
 * data of DeadPacMan
 * Created by Cho keun hee
 * Made on December 2nd 2019
 */

import java.awt.Color;
import java.awt.Graphics;

public class DeadPacMan extends Face{
	
	public DeadPacMan(int size_ , int x_ , int y_ , int angle_ ){
		super(size_ , x_ , y_ , angle_ );
	}
	
	public void make(Graphics g) {
		int xCenter = getXCenter();
		int yCenter = getYCenter();
		int size = getSize();
		super.Deadmake(g);
		g.setColor(Color.black);
		
		int[] x1 = {xCenter - size * 1/10, xCenter - size * 3/20, xCenter + size * 1/10, xCenter + size * 3/20};
		int[] y1 = {yCenter - size * 2/5, yCenter - size * 7/20 , yCenter - size * 4/20, yCenter - size * 5/20};
		int[] y2 = {yCenter - size * 4/20, yCenter - size * 5/20, yCenter - size * 2/5, yCenter - size * 7/20};
		
		g.fillPolygon(x1,y1,4);
		g.fillPolygon(x1,y2,4);
		
	}
}